DROP INDEX `space_date_unique`;--> statement-breakpoint
ALTER TABLE `reservations` ADD `period` text DEFAULT 'day' NOT NULL;--> statement-breakpoint
ALTER TABLE `reservations` ADD `block` text DEFAULT 'Bloco Bento' NOT NULL;--> statement-breakpoint
ALTER TABLE `reservations` ADD `phone_normalized` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `reservations` ADD `cancellation_code_hash` text DEFAULT '' NOT NULL;--> statement-breakpoint
UPDATE `reservations` SET `space` = 'bento' WHERE `space` = 'mirante';--> statement-breakpoint
UPDATE `reservations` SET `space` = 'blumenau' WHERE `space` = 'jardim';--> statement-breakpoint
CREATE UNIQUE INDEX `space_date_period_unique` ON `reservations` (`space`,`date`,`period`);
