CREATE TABLE `audit_events` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`reservation_id` integer NOT NULL,
	`action` text NOT NULL,
	`space` text NOT NULL,
	`date` text NOT NULL,
	`period` text NOT NULL,
	`resident_name` text NOT NULL,
	`apartment` text NOT NULL,
	`block` text NOT NULL,
	`whatsapp` text NOT NULL,
	`occurred_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `audit_events_occurred_at_idx` ON `audit_events` (`occurred_at`);--> statement-breakpoint
CREATE INDEX `audit_events_date_idx` ON `audit_events` (`date`);--> statement-breakpoint
DROP INDEX `space_date_period_unique`;--> statement-breakpoint
ALTER TABLE `reservations` ADD `status` text DEFAULT 'active' NOT NULL;--> statement-breakpoint
ALTER TABLE `reservations` ADD `cancelled_at` text;--> statement-breakpoint
CREATE UNIQUE INDEX `active_space_date_period_unique` ON `reservations` (`space`,`date`,`period`) WHERE "reservations"."status" = 'active';
--> statement-breakpoint
INSERT INTO `audit_events` (`reservation_id`,`action`,`space`,`date`,`period`,`resident_name`,`apartment`,`block`,`whatsapp`,`occurred_at`)
SELECT `id`,'reservation_created',`space`,`date`,`period`,`resident_name`,`apartment`,`block`,`whatsapp`,`created_at` FROM `reservations`;
--> statement-breakpoint
CREATE TRIGGER `reservations_audit_insert` AFTER INSERT ON `reservations`
BEGIN
  INSERT INTO `audit_events` (`reservation_id`,`action`,`space`,`date`,`period`,`resident_name`,`apartment`,`block`,`whatsapp`,`occurred_at`)
  VALUES (NEW.`id`,'reservation_created',NEW.`space`,NEW.`date`,NEW.`period`,NEW.`resident_name`,NEW.`apartment`,NEW.`block`,NEW.`whatsapp`,NEW.`created_at`);
END;
--> statement-breakpoint
CREATE TRIGGER `reservations_audit_cancel` AFTER UPDATE OF `status` ON `reservations`
WHEN OLD.`status` = 'active' AND NEW.`status` = 'cancelled'
BEGIN
  INSERT INTO `audit_events` (`reservation_id`,`action`,`space`,`date`,`period`,`resident_name`,`apartment`,`block`,`whatsapp`,`occurred_at`)
  VALUES (NEW.`id`,'reservation_cancelled',NEW.`space`,NEW.`date`,NEW.`period`,NEW.`resident_name`,NEW.`apartment`,NEW.`block`,NEW.`whatsapp`,COALESCE(NEW.`cancelled_at`,CURRENT_TIMESTAMP));
END;
