CREATE TABLE `reservations` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`space` text NOT NULL,
	`date` text NOT NULL,
	`resident_name` text NOT NULL,
	`apartment` text NOT NULL,
	`whatsapp` text NOT NULL,
	`rules_accepted` integer NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `space_date_unique` ON `reservations` (`space`,`date`);