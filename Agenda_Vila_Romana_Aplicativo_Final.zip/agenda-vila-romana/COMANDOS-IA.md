# Comandos diretos para construir o aplicativo

Use um comando por vez e só avance quando a etapa anterior estiver funcionando. Não peça alternativas de layout, explicações longas ou tecnologias opcionais.

## 1. Estrutura

> Crie um aplicativo responsivo em português para reserva de duas churrasqueiras de condomínio. Use somente três etapas: página inicial, seleção de data e finalização. Não adicione login, painel administrativo, pagamento, avaliações ou recursos não solicitados. Os espaços são “Churrasqueira Mirante”, capacidade 25 pessoas, e “Churrasqueira Jardim”, capacidade 15 pessoas.

## 2. Página inicial

> Crie a página inicial com o título “Seu encontro começa aqui”, uma explicação curta, dois cards dos espaços e um botão “Escolher este espaço” em cada card. Ao clicar, abrir a etapa do calendário já com o espaço escolhido. Use visual acolhedor com fundo creme, verde escuro e laranja. Priorize celular.

## 3. Calendário

> Crie a etapa de calendário somente para agosto, setembro, outubro, novembro e dezembro de 2026. Permita navegar apenas entre esses cinco meses. Mostre datas disponíveis, selecionada e indisponíveis com estados visuais distintos. Datas já reservadas não podem ser clicadas. O usuário escolhe somente uma data por reserva.

## 4. Formulário

> Depois da data, mostre um resumo com espaço, data e horário de uso. Crie campos obrigatórios: nome completo, apartamento e WhatsApp. Adicione checkbox obrigatório “Li e aceito as regras de uso do espaço”. O botão “Concluir reserva” só fica habilitado com todos os campos válidos e o aceite marcado.

## 5. Banco e bloqueio de data

> Crie uma tabela `reservations` com: id, space, date, resident_name, apartment, whatsapp, rules_accepted e created_at. Crie restrição única combinando `space` e `date`. Ao concluir, grave a reserva no servidor. Se a combinação espaço + data já existir, rejeite a operação e peça outra data. Depois do sucesso, atualize o calendário para deixar a data indisponível apenas naquele espaço.

## 6. Regras e validação final

> Use estas regras: horário das 10h às 22h; respeitar a capacidade; manter o espaço limpo; devolver chaves e itens como recebidos. Valide no servidor todos os campos, o aceite e a data entre 01/08/2026 e 31/12/2026. Teste o fluxo completo em celular e desktop. Não altere o design nem crie novas funções; apenas corrija erros encontrados.

## 7. Publicação definitiva

> Esta é a única publicação e não haverá manutenção posterior. Remova todos os dados fictícios. Bloqueie automaticamente datas anteriores ao dia atual no fuso America/Sao_Paulo. Se o banco estiver indisponível, impeça novas reservas e mostre erro; nunca simule sucesso. Execute testes de reserva válida, campos vazios, data passada, data fora do período, dupla reserva e falha do banco. Só publique se todos passarem.

## Critérios objetivos de aceite

- Três etapas e dois espaços.
- Calendário limitado a agosto–dezembro de 2026.
- Uma reserva bloqueia a mesma data somente no espaço escolhido.
- Nome, apartamento, WhatsApp e aceite são obrigatórios.
- Dupla reserva é impedida no banco, não apenas na tela.
- Tela de sucesso exibe data, espaço e WhatsApp.
