import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const reservations = sqliteTable("reservations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  space: text("space").notNull(),
  date: text("date").notNull(),
  period: text("period").notNull(),
  residentName: text("resident_name").notNull(),
  apartment: text("apartment").notNull(),
  block: text("block").notNull(),
  whatsapp: text("whatsapp").notNull(),
  phoneNormalized: text("phone_normalized").notNull(),
  cancellationCodeHash: text("cancellation_code_hash").notNull(),
  rulesAccepted: integer("rules_accepted", { mode: "boolean" }).notNull(),
  status: text("status").notNull().default("active"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  cancelledAt: text("cancelled_at"),
}, (table) => [uniqueIndex("active_space_date_period_unique").on(table.space, table.date, table.period).where(sql`${table.status} = 'active'`)]);

export const auditEvents = sqliteTable("audit_events", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  reservationId: integer("reservation_id").notNull(),
  action: text("action").notNull(),
  space: text("space").notNull(),
  date: text("date").notNull(),
  period: text("period").notNull(),
  residentName: text("resident_name").notNull(),
  apartment: text("apartment").notNull(),
  block: text("block").notNull(),
  whatsapp: text("whatsapp").notNull(),
  occurredAt: text("occurred_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("audit_events_occurred_at_idx").on(table.occurredAt), index("audit_events_date_idx").on(table.date)]);
