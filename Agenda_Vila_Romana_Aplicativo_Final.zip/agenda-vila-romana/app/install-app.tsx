"use client";

import { useEffect, useState } from "react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

export default function InstallApp() {
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showOnDevice, setShowOnDevice] = useState(false);
  const [manualHelp, setManualHelp] = useState(false);

  useEffect(() => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches;
    const android = /Android/i.test(navigator.userAgent);
    const deviceCheck = window.requestAnimationFrame(() => {
      setShowOnDevice(android && !standalone);
    });

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }

    const handleInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
      setShowOnDevice(true);
    };
    const handleInstalled = () => {
      setInstallPrompt(null);
      setShowOnDevice(false);
    };

    window.addEventListener("beforeinstallprompt", handleInstallPrompt);
    window.addEventListener("appinstalled", handleInstalled);
    return () => {
      window.cancelAnimationFrame(deviceCheck);
      window.removeEventListener("beforeinstallprompt", handleInstallPrompt);
      window.removeEventListener("appinstalled", handleInstalled);
    };
  }, []);

  async function install() {
    if (!installPrompt) {
      setManualHelp(true);
      return;
    }

    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") {
      setShowOnDevice(false);
    }
    setInstallPrompt(null);
  }

  if (!showOnDevice) return null;

  return (
    <aside className="install-app-card" aria-label="Instalar aplicativo">
      <div>
        <strong>Tenha a agenda sempre à mão</strong>
        <span>Adicione o aplicativo à tela inicial do celular.</span>
      </div>
      <button type="button" onClick={install}>
        <span aria-hidden="true">↓</span> Instalar aplicativo
      </button>
      {manualHelp && (
        <p role="status">
          No Chrome, toque no menu <b>⋮</b> e escolha <b>Instalar aplicativo</b> ou <b>Adicionar à tela inicial</b>.
        </p>
      )}
    </aside>
  );
}
