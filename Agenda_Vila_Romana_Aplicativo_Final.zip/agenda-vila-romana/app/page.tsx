"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import InstallApp from "./install-app";

type SpaceId = "bento" | "blumenau";
type Period = "day" | "night";
type Step = "home" | "calendar" | "form" | "success";
type PublicReservation = { space: SpaceId; date: string; period: Period; apartment: string; block: string };

const NAVY = "#001b50";
const GOLD = "#e89b00";
const spaces: Record<SpaceId, { name: string; short: string }> = {
  bento: { name: "Churrasqueira Quiosque Bento", short: "Quiosque Bento" },
  blumenau: { name: "Churrasqueira Térreo Blumenau", short: "Térreo Blumenau" },
};
const months = ["Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
const monthNumbers = [7, 8, 9, 10, 11];
const holidayEves = new Set(["2026-09-06", "2026-10-11", "2026-11-01", "2026-11-14", "2026-11-19", "2026-12-24"]);

function isoDate(month: number, day: number) { return `2026-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`; }
function todaySP() {
  const p = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const o = Object.fromEntries(p.map((x) => [x.type, x.value])); return `${o.year}-${o.month}-${o.day}`;
}
function longDate(value: string) { return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(`${value}T12:00:00Z`)); }
function nightEnd(date: string) { const day = new Date(`${date}T12:00:00Z`).getUTCDay(); return day === 0 || day === 6 || holidayEves.has(date) ? "00h" : "22h"; }
function periodLabel(period: Period, date: string) { return period === "day" ? "Dia · 09h às 17h" : `Noite · 17h às ${nightEnd(date)}`; }
function normalizePhone(v: string) { return v.replace(/\D/g, ""); }

function Brand() { return <div className="cc-brand"><Image unoptimized src="/condoclub-logo-completo.png" width={600} height={240} alt="CondoClub — Rede de Benefícios para Condomínios"/></div>; }
function BuildingIcon() { return <Image unoptimized className="condo-icon" src="/condominio-vila-romana-icon.png" width={150} height={150} alt="" aria-hidden="true"/>; }

function AppHeader({ title, back }: { title: string; back?: () => void }) {
  return <header className="app-header">{back ? <button onClick={back} aria-label="Voltar">←</button> : <BuildingIcon/>}<h1>{title}</h1></header>;
}

function Calendar({ monthIndex, selected, reservations, space, onSelect }: { monthIndex: number; selected: string; reservations: PublicReservation[]; space: SpaceId; onSelect: (d: string) => void }) {
  const month = monthNumbers[monthIndex];
  const first = new Date(Date.UTC(2026, month, 1)).getUTCDay();
  const total = new Date(Date.UTC(2026, month + 1, 0)).getUTCDate();
  const cells = [...Array(first).fill(null), ...Array.from({ length: total }, (_, i) => i + 1)];
  return <div className="calendar-card">
    <div className="weekdays">{["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB"].map((x) => <span key={x}>{x}</span>)}</div>
    <div className="calendar-days">{cells.map((day, i) => {
      if (!day) return <span key={`e${i}`}/>;
      const date = isoDate(month, day); const past = date < todaySP();
      const count = reservations.filter((r) => r.space === space && r.date === date).length;
      return <button key={date} disabled={past} className={`${selected === date ? "selected" : ""} ${count === 2 ? "full" : ""}`} onClick={() => onSelect(date)} aria-label={`${day} de ${months[monthIndex]}`}><b>{day}</b>{count === 1 && <i/>}</button>;
    })}</div>
  </div>;
}

export default function Home() {
  const [step, setStep] = useState<Step>("home");
  const [space, setSpace] = useState<SpaceId | "">("");
  const [monthIndex, setMonthIndex] = useState(0);
  const [date, setDate] = useState("");
  const [period, setPeriod] = useState<Period | "">("");
  const [reservations, setReservations] = useState<PublicReservation[]>([]);
  const [calendarError, setCalendarError] = useState("");
  const [termsOpen, setTermsOpen] = useState(false);
  const [entryGuide, setEntryGuide] = useState<"reserve" | "cancel" | null>(null);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [cancelTarget, setCancelTarget] = useState<PublicReservation | null>(null);
  const [cancel, setCancel] = useState({ whatsapp: "", code: "" });
  const [form, setForm] = useState({ name: "", apartment: "", block: "", whatsapp: "" });
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const loadReservations = useCallback(async () => {
    setCalendarError("");
    try { const r = await fetch("/api/reservations", { cache: "no-store" }); if (!r.ok) throw new Error(); const d = await r.json(); setReservations(d.reservations); }
    catch { setCalendarError("Não foi possível consultar a agenda. Recarregue a página."); }
  }, []);
  useEffect(() => {
    fetch("/api/reservations", { cache: "no-store" })
      .then((r) => { if (!r.ok) throw new Error(); return r.json(); })
      .then((data) => setReservations(data.reservations))
      .catch(() => setCalendarError("Não foi possível consultar a agenda. Recarregue a página."));
  }, []);

  const dateReservations = useMemo(() => reservations.filter((r) => r.space === space && r.date === date), [reservations, space, date]);
  const selectedReservation = (p: Period) => dateReservations.find((r) => r.period === p);

  function startCalendar() { if (!space) return; setEntryGuide(null); setDate(""); setPeriod(""); setStep("calendar"); window.scrollTo(0, 0); }
  function reset() { setStep("home"); setSpace(""); setDate(""); setPeriod(""); setCode(""); setForm({ name: "", apartment: "", block: "", whatsapp: "" }); setTermsAccepted(false); }

  async function createReservation() {
    if (!termsAccepted || !space || !date || !period) return;
    setLoading(true); setMessage("");
    try {
      const r = await fetch("/api/reservations", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ ...form, space, date, period, accepted: true }) });
      const data = await r.json(); if (!r.ok) { setMessage(data.error ?? "Não foi possível reservar."); return; }
      setCode(data.reservation.cancellationCode); setTermsOpen(false); setStep("success"); await loadReservations(); window.scrollTo(0, 0);
    } finally { setLoading(false); }
  }

  async function cancelReservation(e: React.FormEvent) {
    e.preventDefault(); if (!cancelTarget) return; setLoading(true); setMessage("");
    try {
      const r = await fetch("/api/reservations", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ space: cancelTarget.space, date: cancelTarget.date, period: cancelTarget.period, whatsapp: cancel.whatsapp, code: cancel.code }) });
      const data = await r.json(); if (!r.ok) { setMessage(data.error ?? "Não foi possível cancelar."); return; }
      setCancelTarget(null); setCancel({ whatsapp: "", code: "" }); setMessage("Reserva cancelada. O período está disponível novamente."); await loadReservations();
    } finally { setLoading(false); }
  }

  async function saveConfirmation() {
    if (!space || !period) return;
    const canvas = document.createElement("canvas"); canvas.width = 1080; canvas.height = 1920; const c = canvas.getContext("2d"); if (!c) return;
    const rounded = (x: number, y: number, w: number, h: number, r: number, fill: string, stroke?: string) => { c.beginPath(); c.roundRect(x, y, w, h, r); c.fillStyle = fill; c.fill(); if (stroke) { c.strokeStyle = stroke; c.lineWidth = 3; c.stroke(); } };
    const wrap = (text: string, x: number, y: number, max: number, line: number) => { const words = text.split(" "); let row = ""; let yy = y; for (const word of words) { const test = `${row}${word} `; if (c.measureText(test).width > max && row) { c.fillText(row.trim(), x, yy); row = `${word} `; yy += line; } else row = test; } if (row) c.fillText(row.trim(), x, yy); return yy; };
    c.fillStyle = "#fff"; c.fillRect(0, 0, 1080, 1920); c.fillStyle = NAVY; c.fillRect(0, 0, 1080, 150);
    c.fillStyle = "#fff"; c.font = "bold 50px Arial"; c.fillText("Reserva confirmada", 64, 94);
    c.strokeStyle = GOLD; c.lineWidth = 7; c.beginPath(); c.arc(540, 238, 46, 0, Math.PI * 2); c.stroke(); c.beginPath(); c.moveTo(518, 238); c.lineTo(535, 255); c.lineTo(566, 220); c.stroke();
    c.fillStyle = NAVY; c.textAlign = "center"; c.font = "bold 42px Arial"; c.fillText("Reserva realizada com sucesso!", 540, 330); c.font = "28px Arial"; c.fillText("Guarde as informações abaixo.", 540, 377); c.textAlign = "left";
    rounded(42, 420, 996, 670, 24, "#fff", "#cbd3df"); c.fillStyle = NAVY; c.font = "bold 38px Arial"; c.fillText("Detalhes da reserva", 78, 478);
    const details = [["Espaço", spaces[space].name], ["Data", longDate(date)], ["Período", periodLabel(period, date)], ["Responsável", form.name], ["Apartamento", `${form.apartment} · ${form.block}`], ["WhatsApp", form.whatsapp]];
    details.forEach(([label, value], i) => { const y = 535 + i * 88; if (i) { c.strokeStyle = "#d6dce5"; c.lineWidth = 2; c.beginPath(); c.moveTo(78, y - 24); c.lineTo(1002, y - 24); c.stroke(); } c.fillStyle = "#65718a"; c.font = "24px Arial"; c.fillText(label, 78, y); c.fillStyle = NAVY; c.font = "bold 29px Arial"; c.fillText(value, 78, y + 38); });
    rounded(42, 1120, 996, 570, 24, "#fff9ee", "#e89b00"); c.fillStyle = "#c87500"; c.font = "bold 38px Arial"; c.fillText("Código para cancelamento", 82, 1185);
    const boxW = 150; const gap = 24; const start = (1080 - (boxW * 4 + gap * 3)) / 2; code.split("").forEach((digit, i) => { rounded(start + i * (boxW + gap), 1235, boxW, 155, 16, "#fff", "#e89b00"); c.fillStyle = "#c87500"; c.textAlign = "center"; c.font = "bold 82px Arial"; c.fillText(digit, start + i * (boxW + gap) + boxW / 2, 1340); }); c.textAlign = "left";
    c.fillStyle = NAVY; c.font = "27px Arial"; c.textAlign = "center"; wrap("Caso queira cancelar sua reserva, procure a data no calendário e informe seu WhatsApp e o código de cancelamento.", 540, 1460, 840, 40); c.textAlign = "left";
    rounded(82, 1540, 916, 92, 12, "#fff0ca"); c.fillStyle = NAVY; c.font = "bold 25px Arial"; c.textAlign = "center"; c.fillText("⚠ Guarde este código no celular. Não será possível recuperá-lo.", 540, 1596); c.textAlign = "left";
    const logo = new window.Image(); logo.src = "/condoclub-logo-completo.png"; try { await logo.decode(); c.drawImage(logo, 290, 1700, 500, 200); } catch { c.fillStyle = NAVY; c.font = "42px Arial"; c.fillText("CondoClub", 430, 1810); }
    const a = document.createElement("a"); a.download = `reserva-${date}-${period}.png`; a.href = canvas.toDataURL("image/png"); a.click();
  }

  return <main className="app-shell">
    {step === "home" && <section className="screen home-screen">
      <div className="home-head"><BuildingIcon/><div><h1>Agenda de reserva<br/>das churrasqueiras</h1><p>Condomínio Vila Romana</p></div></div>
      <div className="screen-body"><h2>▣ <span>Escolha o espaço</span></h2>
        <div className="space-options">{(Object.keys(spaces) as SpaceId[]).map((id) => <button key={id} className={space === id ? "active" : ""} onClick={() => setSpace(id)}><span className="space-icon">⌂</span><b>{spaces[id].name}</b><i/></button>)}</div>
        <button className="main-button" disabled={!space} onClick={() => setEntryGuide("reserve")}>▣ <span>Faça sua reserva</span></button>
        <button className="main-button cancel-start-button" disabled={!space} onClick={() => setEntryGuide("cancel")}>× <span>Cancelar reserva</span></button>
        <InstallApp/>
        <div className="booking-scope-note"><b>Importante:</b> este aplicativo é exclusivo para reservas das churrasqueiras. A reserva do salão de festas deve ser feita obrigatoriamente com o zelador, Sr. Valdecir, pelo WhatsApp.</div>
      </div>
      <footer className="promo-footer"><Brand/><p>Este aplicativo é uma cortesia da Rede CondoClub, oferecido gratuitamente e sem custos para o condomínio.<br/>Acesse <a href="https://redecondoclub.vercel.app" target="_blank" rel="noreferrer">redecondoclub.vercel.app</a> e veja os benefícios para moradores.</p><Link className="admin-access-link" href="/admin">Acesso administrativo</Link><small>CondoClub Benefícios é um produto da Vercel Tecnologia da Informação LTDA.</small></footer>
      {entryGuide && <div className="modal-backdrop"><div className="terms-modal entry-guide-modal" role="dialog" aria-modal="true" aria-labelledby="entry-guide-title"><h2 id="entry-guide-title">{entryGuide === "reserve" ? "Orientação para reservar" : "Orientação para cancelar"}</h2>{entryGuide === "reserve" ? <><p>Use a agenda com responsabilidade. Evite reservas seguidas ou excessivas em sextas-feiras, finais de semana e outras datas concorridas, permitindo que outros moradores também utilizem os espaços.</p><strong>O uso indevido da agenda poderá resultar no cancelamento da reserva.</strong></> : <p>Para cancelar uma reserva, abra a agenda, localize a data e toque no período reservado. Depois, informe o WhatsApp cadastrado e o código de cancelamento de quatro dígitos recebido na confirmação.</p>}<div className="modal-actions"><button onClick={() => setEntryGuide(null)}>Voltar</button><button onClick={startCalendar}>{entryGuide === "reserve" ? "Li e entendi — continuar" : "Ir para a agenda"}</button></div></div></div>}
    </section>}

    {step === "calendar" && space && <section className="screen compact-screen">
      <AppHeader title="Escolha a data" back={() => setStep("home")}/>
      <div className="selected-space"><span className="space-icon">⌂</span><b>{spaces[space].name}</b></div>
      <div className="legend-row"><span><i/>Disponível</span><span><i className="gold"/>Selecionado</span><span><i className="slash"/>Sem períodos</span></div>
      {calendarError && <div className="error">{calendarError}</div>}
      <div className="month-nav"><button disabled={monthIndex === 0} onClick={() => setMonthIndex((x) => x - 1)}>‹</button><h2>{months[monthIndex]} 2026</h2><button disabled={monthIndex === 4} onClick={() => setMonthIndex((x) => x + 1)}>›</button></div>
      <Calendar monthIndex={monthIndex} selected={date} reservations={reservations} space={space} onSelect={(d) => { setDate(d); setPeriod(""); setMessage(""); }}/>
      <div className="period-area"><h3>Escolha o período</h3>{(["day", "night"] as Period[]).map((p) => {
        const booked = selectedReservation(p); return <button key={p} disabled={!date} className={`period-option ${period === p ? "active" : ""} ${booked ? "booked" : ""}`} onClick={() => booked ? setCancelTarget(booked) : setPeriod(p)}><i/><span><b>{p === "day" ? "Dia" : "Noite"}</b><small>{p === "day" ? "09h às 17h" : `17h às ${date ? nightEnd(date) : "22h"}`}</small></span><em>{booked ? `Reservado · Apto. ${booked.apartment} · ${booked.block}` : "Disponível"}</em></button>;
      })}<p>Finais de semana e vésperas de feriado: até 00h.<br/><strong>Nos demais dias: até 22h.</strong></p><div className="silence">🔇 <b>EVITE MULTAS, RESPEITE O HORÁRIO DE SILÊNCIO</b></div></div>
      {message && <div className="success-note">{message}</div>}
      <button className="main-button continue" disabled={!date || !period} onClick={() => setStep("form")}>Continuar</button><Brand/>
    </section>}

    {step === "form" && space && period && <section className="screen compact-screen form-screen">
      <AppHeader title="Finalizar reserva" back={() => setStep("calendar")}/>
      <div className="booking-summary"><span className="space-icon">⌂</span><div><b>{spaces[space].name}</b><span>{longDate(date)}</span><small>{periodLabel(period, date)}</small></div></div>
      <form onSubmit={(e) => { e.preventDefault(); if (form.name && form.apartment && form.block && normalizePhone(form.whatsapp).length >= 10) setTermsOpen(true); }} className="resident-form"><h2>Identificação do responsável</h2>
        <label>Nome do responsável<input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Digite o nome completo"/></label>
        <div className="form-row"><label>Apartamento<input required value={form.apartment} onChange={(e) => setForm({ ...form, apartment: e.target.value })} placeholder="Ex.: 204"/></label><label>Bloco<select required value={form.block} onChange={(e) => setForm({ ...form, block: e.target.value })}><option value="">Selecione o bloco</option><option>Bloco Bento</option><option>Bloco Blumenau</option></select></label></div>
        <label>WhatsApp<input required inputMode="tel" value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} placeholder="(00) 00000-0000"/></label>
        {message && <div className="error">{message}</div>}<button className="main-button">Concluir reserva</button>
      </form><Brand/>
      {termsOpen && <div className="modal-backdrop"><div className="terms-modal" role="dialog" aria-modal="true" aria-labelledby="terms-title"><h2 id="terms-title">♢ Termos de uso do espaço</h2><ul><li>Respeite o horário de silêncio: até 22h nos dias comuns e até 00h em finais de semana e vésperas de feriado.</li><li>O responsável pela reserva responde pela conduta de seus convidados.</li><li>O espaço deve ser devolvido limpo e organizado, conforme foi recebido.</li><li>Respeite a capacidade e preserve móveis, equipamentos e áreas comuns.</li></ul><label className="accept"><input type="checkbox" checked={termsAccepted} onChange={(e) => setTermsAccepted(e.target.checked)}/> Declaro que li e aceito os termos de uso.</label><div className="modal-actions"><button onClick={() => setTermsOpen(false)}>Voltar</button><button disabled={!termsAccepted || loading} onClick={createReservation}>{loading ? "Confirmando…" : "Li e aceito"}</button></div></div></div>}
    </section>}

    {step === "success" && space && period && <section className="screen compact-screen success-screen">
      <AppHeader title="Reserva confirmada"/><div className="success-title"><i>✓</i><h2>Reserva realizada com sucesso!</h2><p>Guarde as informações abaixo.</p></div>
      <div className="details-card"><h2>Detalhes da reserva</h2><dl><div><dt>Espaço</dt><dd>{spaces[space].name}</dd></div><div><dt>Data</dt><dd>{longDate(date)}</dd></div><div><dt>Período</dt><dd>{periodLabel(period, date)}</dd></div><div><dt>Responsável</dt><dd>{form.name}</dd></div><div><dt>Apartamento</dt><dd>{form.apartment} · {form.block}</dd></div><div><dt>WhatsApp</dt><dd>{form.whatsapp}</dd></div></dl></div>
      <div className="code-card"><h2>♙ Código para cancelamento</h2><div className="code-digits">{code.split("").map((n, i) => <b key={i}>{n}</b>)}</div><p>Caso queira cancelar sua reserva, procure a data no calendário e informe seu WhatsApp e o código de cancelamento.</p><strong>⚠ Guarde este código no celular. Não será possível recuperá-lo.</strong><button onClick={saveConfirmation}>▧ Salvar confirmação como imagem</button></div>
      <button className="main-button" onClick={reset}>Voltar ao início</button><Brand/>
    </section>}

    {cancelTarget && <div className="modal-backdrop"><form className="cancel-modal" onSubmit={cancelReservation}><h2>Cancelar reserva</h2><p>{spaces[cancelTarget.space].name}<br/><b>{longDate(cancelTarget.date)} · {periodLabel(cancelTarget.period, cancelTarget.date)}</b></p><label>WhatsApp cadastrado<input required inputMode="tel" value={cancel.whatsapp} onChange={(e) => setCancel({ ...cancel, whatsapp: e.target.value })} placeholder="(00) 00000-0000"/></label><label>Código de cancelamento<input required inputMode="numeric" pattern="[0-9]{4}" maxLength={4} value={cancel.code} onChange={(e) => setCancel({ ...cancel, code: e.target.value.replace(/\D/g, "") })} placeholder="4 dígitos"/></label>{message && <div className="error">{message}</div>}<div className="modal-actions"><button type="button" onClick={() => { setCancelTarget(null); setMessage(""); }}>Voltar</button><button disabled={loading}>{loading ? "Cancelando…" : "Confirmar cancelamento"}</button></div></form></div>}
  </main>;
}
