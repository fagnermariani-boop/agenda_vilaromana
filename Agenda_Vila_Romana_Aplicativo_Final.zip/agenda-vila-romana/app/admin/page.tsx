"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";

type AuditEvent = {
  id: number;
  reservationId: number;
  action: "reservation_created" | "reservation_cancelled";
  space: "bento" | "blumenau";
  date: string;
  period: "day" | "night";
  residentName: string;
  apartment: string;
  block: string;
  whatsapp: string;
  occurredAt: string;
};

const spaces = { bento: "Churrasqueira Quiosque Bento", blumenau: "Churrasqueira Térreo Blumenau" };

function dateLabel(value: string) {
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(`${value}T12:00:00Z`));
}

function eventTime(value: string) {
  const normalized = value.includes("T") ? value : `${value.replace(" ", "T")}Z`;
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: "America/Sao_Paulo" }).format(new Date(normalized));
}

function Brand() {
  return <div className="cc-brand"><Image unoptimized src="/condoclub-logo-completo.png" width={600} height={240} alt="CondoClub — Rede de Benefícios para Condomínios"/></div>;
}

export default function AdminPage() {
  const [checking, setChecking] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [credentials, setCredentials] = useState({ username: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const loadEvents = useCallback(async () => {
    const response = await fetch("/api/admin/audit", { cache: "no-store" });
    if (response.status === 401) { setAuthenticated(false); return; }
    const data = await response.json();
    if (!response.ok) throw new Error(data.error ?? "Não foi possível carregar o histórico.");
    setEvents(data.events);
  }, []);

  useEffect(() => {
    fetch("/api/admin/session", { cache: "no-store" }).then((response) => response.json()).then(async (data) => {
      setAuthenticated(Boolean(data.authenticated));
      if (data.authenticated) await loadEvents();
    }).catch(() => setError("Não foi possível verificar o acesso." )).finally(() => setChecking(false));
  }, [loadEvents]);

  async function login(event: FormEvent) {
    event.preventDefault(); setLoading(true); setError("");
    try {
      const response = await fetch("/api/admin/session", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(credentials) });
      const data = await response.json();
      if (!response.ok) { setError(data.error ?? "Acesso não autorizado."); return; }
      setAuthenticated(true); setCredentials({ username: "", password: "" }); await loadEvents();
    } catch { setError("Não foi possível entrar agora."); }
    finally { setLoading(false); }
  }

  async function logout() {
    await fetch("/api/admin/session", { method: "DELETE" }); setAuthenticated(false); setEvents([]);
  }

  return <main className="app-shell"><section className="screen admin-screen">
    <div className="home-head admin-head"><Image unoptimized className="condo-icon" src="/condominio-vila-romana-icon.png" width={150} height={150} alt="" aria-hidden="true"/><div><h1>Painel administrativo</h1><p>Condomínio Vila Romana</p></div></div>
    {checking ? <div className="admin-loading">Verificando acesso…</div> : !authenticated ? <>
      <div className="admin-login-wrap"><div className="admin-login-card"><h2>🔒 Acesso do administrador</h2><p>Entre para consultar o histórico permanente de reservas e cancelamentos.</p>
        <form onSubmit={login}><label>Usuário<input autoComplete="username" required value={credentials.username} onChange={(event) => setCredentials({ ...credentials, username: event.target.value })}/></label><label>Senha<div className="password-field"><input type={showPassword ? "text" : "password"} autoComplete="current-password" required value={credentials.password} onChange={(event) => setCredentials({ ...credentials, password: event.target.value })}/><button type="button" aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"} aria-pressed={showPassword} onClick={() => setShowPassword((current) => !current)}>👁 {showPassword ? "Ocultar" : "Mostrar"}</button></div></label>{error && <div className="error admin-error">{error}</div>}<button className="main-button" disabled={loading}>{loading ? "Entrando…" : "Entrar"}</button></form>
        <Link className="back-home" href="/">← Voltar para a agenda</Link></div></div><Brand/>
    </> : <>
      <div className="admin-toolbar"><div><h2>Histórico de operações</h2><p>{events.length} {events.length === 1 ? "registro" : "registros"}</p></div><button onClick={logout}>Sair</button></div>
      {error && <div className="error">{error}</div>}
      <div className="audit-list">{events.length === 0 ? <div className="audit-empty">Ainda não existem operações registradas.</div> : events.map((item) => <article key={item.id} className={`audit-entry ${item.action === "reservation_cancelled" ? "cancelled" : "created"}`}>
        <div className="audit-entry-head"><strong>{item.action === "reservation_cancelled" ? "RESERVA CANCELADA" : "RESERVA REALIZADA"}</strong><time>{eventTime(item.occurredAt)}</time></div>
        <h3>Apartamento {item.apartment} · {item.block}</h3>
        <dl><div><dt>Responsável</dt><dd>{item.residentName}</dd></div><div><dt>WhatsApp</dt><dd>{item.whatsapp}</dd></div><div><dt>Espaço</dt><dd>{spaces[item.space]}</dd></div><div><dt>Data reservada</dt><dd>{dateLabel(item.date)}</dd></div><div><dt>Período</dt><dd>{item.period === "day" ? "Dia · 09h às 17h" : "Noite · a partir das 17h"}</dd></div><div><dt>Identificação</dt><dd>Reserva nº {item.reservationId}</dd></div></dl>
      </article>)}</div>
      <div className="admin-note">Os registros deste histórico são mantidos mesmo quando uma reserva é cancelada.</div><Brand/>
    </>}
  </section></main>;
}
