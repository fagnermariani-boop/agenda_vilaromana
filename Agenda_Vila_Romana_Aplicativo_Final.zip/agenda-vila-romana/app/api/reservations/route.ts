import { and, asc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { reservations } from "../../../db/schema";

const datePattern = /^2026-(08|09|10|11|12)-\d{2}$/;
const spaces = ["bento", "blumenau"];
const periods = ["day", "night"];
const blocks = ["Bloco Bento", "Bloco Blumenau"];
const normalizePhone = (value: string) => value.replace(/\D/g, "");

function todaySP() {
  const p = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const o = Object.fromEntries(p.map((x) => [x.type, x.value])); return `${o.year}-${o.month}-${o.day}`;
}
async function hashSecret(phone: string, code: string) {
  const bytes = new TextEncoder().encode(`${phone}:${code}`);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function makeCode() { const values = new Uint32Array(1); crypto.getRandomValues(values); return String(1000 + (values[0] % 9000)); }
function validDate(value: string) { const d = new Date(`${value}T12:00:00Z`); return datePattern.test(value) && !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value && value >= todaySP() && value <= "2026-12-31"; }

export async function GET() {
  try {
    const db = await getDb();
    const rows = await db.select({ space: reservations.space, date: reservations.date, period: reservations.period, apartment: reservations.apartment, block: reservations.block }).from(reservations).where(eq(reservations.status, "active")).orderBy(asc(reservations.date));
    return Response.json({ reservations: rows }, { headers: { "cache-control": "no-store" } });
  } catch { return Response.json({ error: "Agenda temporariamente indisponível." }, { status: 503 }); }
}

export async function POST(request: Request) {
  const data = await request.json() as { space?: string; date?: string; period?: string; name?: string; apartment?: string; block?: string; whatsapp?: string; accepted?: boolean };
  const phone = normalizePhone(data.whatsapp ?? "");
  if (!spaces.includes(data.space ?? "") || !periods.includes(data.period ?? "") || !validDate(data.date ?? "") || !data.name?.trim() || !data.apartment?.trim() || !blocks.includes(data.block ?? "") || phone.length < 10 || phone.length > 11 || data.accepted !== true) return Response.json({ error: "Confira os dados e aceite os termos de uso." }, { status: 400 });
  try {
    const code = makeCode(); const codeHash = await hashSecret(phone, code); const db = await getDb();
    const [row] = await db.insert(reservations).values({ space: data.space!, date: data.date!, period: data.period!, residentName: data.name.trim(), apartment: data.apartment.trim(), block: data.block!, whatsapp: data.whatsapp!.trim(), phoneNormalized: phone, cancellationCodeHash: codeHash, rulesAccepted: true }).returning({ id: reservations.id });
    return Response.json({ reservation: { id: row.id, cancellationCode: code } }, { status: 201 });
  } catch (error) {
    const m = error instanceof Error ? error.message : "";
    if (/unique/i.test(m)) return Response.json({ error: "Este período acabou de ser reservado. Escolha outro." }, { status: 409 });
    return Response.json({ error: "Serviço temporariamente indisponível. Nenhuma reserva foi registrada." }, { status: 503 });
  }
}

export async function DELETE(request: Request) {
  const data = await request.json() as { space?: string; date?: string; period?: string; whatsapp?: string; code?: string };
  const phone = normalizePhone(data.whatsapp ?? ""); const code = (data.code ?? "").replace(/\D/g, "");
  if (!spaces.includes(data.space ?? "") || !periods.includes(data.period ?? "") || !datePattern.test(data.date ?? "") || phone.length < 10 || !/^\d{4}$/.test(code)) return Response.json({ error: "Informe o WhatsApp e o código de quatro dígitos." }, { status: 400 });
  try {
    const hash = await hashSecret(phone, code); const db = await getDb();
    const rows = await db.update(reservations).set({ status: "cancelled", cancelledAt: new Date().toISOString() }).where(and(eq(reservations.space, data.space!), eq(reservations.date, data.date!), eq(reservations.period, data.period!), eq(reservations.phoneNormalized, phone), eq(reservations.cancellationCodeHash, hash), eq(reservations.status, "active"))).returning({ id: reservations.id });
    if (!rows.length) return Response.json({ error: "WhatsApp ou código incorreto." }, { status: 403 });
    return Response.json({ cancelled: true });
  } catch { return Response.json({ error: "Não foi possível cancelar agora. Tente novamente." }, { status: 503 }); }
}
