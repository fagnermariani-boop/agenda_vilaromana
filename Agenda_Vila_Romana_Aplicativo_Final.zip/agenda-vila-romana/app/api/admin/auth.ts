const COOKIE_NAME = "vr_admin";
const SESSION_SECONDS = 8 * 60 * 60;

async function runtimeEnv() {
  const { env } = await import("cloudflare:workers");
  return env as unknown as Record<string, string | undefined>;
}

function hex(bytes: ArrayBuffer) {
  return Array.from(new Uint8Array(bytes)).map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function sha256(value: string) {
  return hex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)));
}

async function signature(value: string, secret: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}

function safeEqual(left: string, right: string) {
  if (left.length !== right.length) return false;
  let different = 0;
  for (let index = 0; index < left.length; index++) different |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return different === 0;
}

export async function validateCredentials(username: string, password: string) {
  const env = await runtimeEnv();
  if (!env.ADMIN_USERNAME || !env.ADMIN_PASSWORD_HASH) return false;
  return safeEqual(username, env.ADMIN_USERNAME) && safeEqual(await sha256(password), env.ADMIN_PASSWORD_HASH);
}

export async function createSessionToken() {
  const env = await runtimeEnv();
  if (!env.ADMIN_SESSION_SECRET) throw new Error("Admin session secret unavailable");
  const expires = String(Math.floor(Date.now() / 1000) + SESSION_SECONDS);
  return `${expires}.${await signature(expires, env.ADMIN_SESSION_SECRET)}`;
}

export async function isAdmin(request: Request) {
  const cookie = request.headers.get("cookie") ?? "";
  const token = cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${COOKIE_NAME}=`))?.slice(COOKIE_NAME.length + 1);
  if (!token) return false;
  const [expires, supplied] = token.split(".");
  if (!expires || !supplied || Number(expires) <= Math.floor(Date.now() / 1000)) return false;
  const env = await runtimeEnv();
  if (!env.ADMIN_SESSION_SECRET) return false;
  return safeEqual(supplied, await signature(expires, env.ADMIN_SESSION_SECRET));
}

export function sessionCookie(token: string) {
  return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_SECONDS}`;
}

export function clearSessionCookie() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}
