import { clearSessionCookie, createSessionToken, isAdmin, sessionCookie, validateCredentials } from "../auth";

export async function GET(request: Request) {
  return Response.json({ authenticated: await isAdmin(request) }, { headers: { "cache-control": "no-store" } });
}

export async function POST(request: Request) {
  const data = await request.json() as { username?: string; password?: string };
  if (!await validateCredentials(data.username ?? "", data.password ?? "")) {
    return Response.json({ error: "Usuário ou senha incorretos." }, { status: 401 });
  }
  const token = await createSessionToken();
  return Response.json({ authenticated: true }, { headers: { "set-cookie": sessionCookie(token), "cache-control": "no-store" } });
}

export async function DELETE() {
  return Response.json({ authenticated: false }, { headers: { "set-cookie": clearSessionCookie(), "cache-control": "no-store" } });
}
