import { desc } from "drizzle-orm";
import { getDb } from "../../../../db";
import { auditEvents } from "../../../../db/schema";
import { isAdmin } from "../auth";

export async function GET(request: Request) {
  if (!await isAdmin(request)) return Response.json({ error: "Acesso não autorizado." }, { status: 401 });
  try {
    const db = await getDb();
    const events = await db.select().from(auditEvents).orderBy(desc(auditEvents.occurredAt), desc(auditEvents.id)).limit(1500);
    return Response.json({ events }, { headers: { "cache-control": "no-store" } });
  } catch {
    return Response.json({ error: "Não foi possível carregar o histórico." }, { status: 503 });
  }
}
